<?php
	$arr = array ('username':'jack','age':21,'gender':'male'); 
	echo $arr;	
?>